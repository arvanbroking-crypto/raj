# Arvan Algo

**Arvan Algo** is a full-stack algorithmic trading app for the Indian stock market.

## Features
- Auth (JWT)
- Strategy Backtesting (SMA, RSI, MACD)
- Zerodha Kite Integration
- Razorpay Payments
- Email Alerts via SendGrid
- Dockerized Setup

## Run
```bash
docker-compose up --build
```

Frontend: http://localhost:3000  
Backend: http://localhost:8000