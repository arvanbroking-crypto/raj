# Simple in-memory placeholder
users = {}
preferences = {}
payments = {}