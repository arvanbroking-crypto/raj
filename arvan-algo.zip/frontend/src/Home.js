import React from 'react';
export default function Home() {
  return <div className="text-blue-700 text-2xl">Welcome to Arvan Algo</div>;
}