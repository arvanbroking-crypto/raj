import React from 'react';
export default function Login() {
  return <div className="text-white bg-blue-500 p-4 rounded">Login Page</div>;
}